const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(express.json());
app.use(cors());
app.use(express.static("public"));

mongoose.connect(
"mongodb://127.0.0.1:27017/votingDB"
)
.then(()=>console.log("MongoDB Connected"));

app.use("/auth",require("./routes/authRoutes"));
app.use("/vote",require("./routes/voteRoutes"));

app.listen(5000,()=>{
    console.log("Server Running");
});