const router=require("express").Router();

const User=require("../models/User");
const Candidate=require("../models/Candidate");

router.get("/candidates",async(req,res)=>{
const candidates=await Candidate.find();
res.json(candidates);
});

router.post("/cast",async(req,res)=>{

const {userId,candidateId}=req.body;

const user=await User.findById(userId);

if(user.voted){

return res.json({
message:"Already Voted"
});

}

await Candidate.findByIdAndUpdate(
candidateId,
{$inc:{votes:1}}
);

user.voted=true;

await user.save();

res.json({
message:"Vote Cast Successfully"
});

});

module.exports=router;