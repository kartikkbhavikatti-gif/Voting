router.post("/login",async(req,res)=>{

const {email,password}=req.body;

const user=await User.findOne({email});

if(!user){
return res.status(400).json({
message:"User Not Found"
});
}

const valid=await bcrypt.compare(
password,
user.password
);

if(!valid){
return res.status(400).json({
message:"Wrong Password"
});
}

const token=jwt.sign(
{id:user._id},
"secretkey"
);

res.json({
token,
user
});

});

module.exports=router;