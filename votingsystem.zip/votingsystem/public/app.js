async function signup(){

const name=
document.getElementById("name").value;

const email=
document.getElementById("email").value;

const password=
document.getElementById("password").value;

const response=
await fetch(
"http://localhost:5000/auth/signup",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
name,
email,
password
})
});

const data=await response.json();

alert(data.message);

}

async function login(){

const email=
document.getElementById("loginEmail").value;

const password=
document.getElementById("loginPassword").value;

const response=
await fetch(
"http://localhost:5000/auth/login",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
email,
password
})
});

const data=await response.json();

localStorage.setItem(
"token",
data.token
);

localStorage.setItem(
"userId",
data.user._id
);

alert("Login Success");

window.location="dashboard.html";

}

async function loadCandidates(){
const response=
await fetch(
"http://localhost:5000/vote/candidates"
);

const candidates=await response.json();

const container=
document.getElementById("candidates");

container.innerHTML="";

candidates.forEach(candidate=>{
const div=document.createElement("div");
div.className="candidate";
div.innerHTML=`
<h2>${candidate.candidateName}</h2>
<p>${candidate.party}</p>
<p>Votes: ${candidate.votes}</p>
<button onclick="castVote('${candidate._id}')">Vote</button>
`;
container.appendChild(div);
});
}

async function castVote(candidateId){
const userId=localStorage.getItem("userId");

const response=
await fetch(
"http://localhost:5000/vote/cast",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
userId,
candidateId
})
}
);

const data=await response.json();

alert(data.message);

if(data.message==="Vote Cast Successfully"){
loadCandidates();
}
}