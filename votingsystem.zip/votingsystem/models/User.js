const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    voted:{
        type:Boolean,
        default:false
    },
    role:{
        type:String,
        default:"user"
    }
});

module.exports = mongoose.model("User",userSchema);
